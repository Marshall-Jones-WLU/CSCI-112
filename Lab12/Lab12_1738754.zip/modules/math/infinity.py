INFINITY = "-"



def addWithInfinity(a, b):
   """Adds a and b, with the possibility that either might be infinity."""
   return 0
    
def minWithInfinity(a, b):
   """Finds the minimum of a and b, with the possibility that either might be infinity."""
   return 0
    

def lessThanWithInfinity(a, b):
   """Returns a < b, with the possibility that either might be infinity."""
   return False
   